﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TPL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Task.Factory.StartNew(() => Greeting("Pollob")).ContinueWith(t => label1.Text = t.Result, TaskScheduler.FromCurrentSynchronizationContext());
            //label1.Text = "Hello Pollob";

            ShowGreeting();
        }

        private async void ShowGreeting()
        {
            //POI: Most probably Result causes Thread stall
            //TODO: Why following doesn't work?
            //label1.Text = GreetingAsync("Pollob").Result;


            label1.Text = await GreetingAsync("Pollob");
        }


        private Task<string> GreetingAsync(string name)
        {
            return Task.Factory.StartNew(() => Greeting(name));
        }

        private string Greeting(string name)
        {
            Thread.Sleep(5000);
            return "Hello !" + name;
        }
    }
}
