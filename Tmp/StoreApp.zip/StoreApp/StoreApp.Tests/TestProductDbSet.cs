﻿namespace StoreApp.Tests
{
    using System.Linq;
    using StoreApp.Models;

    //POI: Using TestDbSet for Product entity
    class TestProductDbSet : TestDbSet<Product>
    {
        public override Product Find(params object[] keyValues)
        {
            return this.SingleOrDefault(product => product.Id == (int)keyValues.Single());
        }
    }
}