﻿namespace StoreApp.Models
{
    using System.Data.Entity;

    // POI: IStoreAppContext requires SaveChanges to be implemented. But we are not
    // explicitly implementing that method because DbContext already implements that
    // & because of inheritence that method is available in StoreAppContext. So
    // ultimately we have SaveChanges method implemented

    public class StoreAppContext : DbContext, IStoreAppContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        //
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, please use data migrations.
        // For more information refer to the documentation:
        // http://msdn.microsoft.com/en-us/data/jj591621.aspx

        public StoreAppContext() : base("name=StoreAppContext")
        {
        }

        // POI: IStoreAppContext needs a implementation of Products getter. We have
        // getter & setter for Products. So the getter is actually implemented
        public DbSet<Product> Products { get; set; }

        public void MarkAsModified(Product item)
        {
            Entry(item).State = EntityState.Modified;
        }
    }
}
