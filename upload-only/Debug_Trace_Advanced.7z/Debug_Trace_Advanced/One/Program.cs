﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;

namespace One
{
    class Program
    {
        static readonly Logger _logger = LogManager.GetCurrentClassLogger();

        static void Main(string[] args)
        {
            Console.WriteLine("Will Write in DEBUG Mode");

            Debug.Indent();
            Debug.WriteLine("Outputting to [Output] Window");
            Debug.Unindent();

            _logger.Trace("Tracing With NLog");
            _logger.Info("Info Logging With NLog");

            Debug.Assert(5 < 3, "5 > 3");
        }
    }
}
