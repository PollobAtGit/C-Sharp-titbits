﻿using System;
using NLog;

namespace One
{
    static class NLog
    {
        static Logger _logger = LogManager.GetCurrentClassLogger();

        static void Main()
        {
            _logger.Trace("This is a trace message");
            _logger.Debug("This is a debug message");
            _logger.Info("This is an informational message");
            _logger.Warn("This is a warning message");
            _logger.Error("This is an error message");
            _logger.Fatal("This is a fatal message");

            Console.WriteLine("[Logging] - Done");
            Console.ReadKey();
        }
    }
}
