﻿using System.Diagnostics;
using System.IO;
using System.Web.Http;
using API.MessageHandler;

namespace API
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            var traceWriter = config.EnableSystemDiagnosticsTracing();
            traceWriter.IsVerbose = false;

            //traceWriter.MinimumLevel = System.Web.Http.Tracing.TraceLevel.Info;

            Debug.Listeners.Add(new TextWriterTraceListener(@"C:\Users\pollob\Documents\log.txt"));

            config.MessageHandlers.Add(new CustomLogHandler());

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "web-api/{orgId}/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional },
                constraints: new { orgId = @"\d+" }
            );
        }
    }
}
