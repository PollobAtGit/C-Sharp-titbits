﻿using System.Data.Entity;
using System.Linq;

namespace Basic.Repository
{
    // TODO: Implement Disposable pattern
    public abstract class Repository<T> : IRepository where T : class
    {
        // TODO: Use IOC
        readonly DbContext context = new BloggingContext();

        DbContext Context => context;

        // TODO: Use property
        protected readonly DbSet<T> dataSet;

        protected Repository(UnitOfWork uow)
        {
            uow.Register(this);
            dataSet = Context.Set<T>();
        }

        public T Find(int id) => dataSet.Find(id);

        public T Add(T e) => dataSet.Add(e);

        public void Save() => Context.SaveChanges();

        public T Delete(int id) => dataSet.Remove(dataSet.Find(id));

        public T Delete(T e) => dataSet.Remove(e);

        public int Count() => dataSet.Count();

        public void Update(T e)
        {
            dataSet.Attach(e);
            Context.Entry(e).State = EntityState.Modified;
        }
    }
}
