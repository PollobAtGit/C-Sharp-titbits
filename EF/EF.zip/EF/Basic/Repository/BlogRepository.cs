﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace Basic.Repository
{
    public class BlogRepository : Repository<Blog>
    {
        public BlogRepository(UnitOfWork uow) : base(uow) { }

        public List<Blog> FindByUrl(string url) => dataSet.Where(x => x.Url == url).ToList();

        public List<Blog> FindByRating(double rating) => dataSet.Where(x => Math.Abs(x.Rating - rating) < double.Epsilon).ToList();

    }
}
