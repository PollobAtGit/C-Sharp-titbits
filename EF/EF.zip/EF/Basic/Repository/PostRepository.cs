﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace Basic.Repository
{
    public class PostRepository : Repository<Post>
    {
        public PostRepository(UnitOfWork uow) : base(uow) { }

        public List<Post> FindByTitle(string title) => dataSet.Where(x => x.Title == title).ToList();

        public List<Post> FindByContent(string title) => dataSet.Where(x => x.Content == title).ToList();
    }
}
