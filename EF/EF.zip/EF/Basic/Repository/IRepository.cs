﻿using System;
using System.Data.Entity;
using System.Linq;

namespace Basic
{
    // POI: This non-generic repository will be helpful to keep as a generic repository without specifying type
    public interface IRepository
    {
        int Count();

        void Save();
    }

    // TODO: Implementing IDisposable might cause problem because BlogContext is registered as singleton in Autofac
    // & using IRepository in a using block (as an example) will try to dispose the DbContext provided
    //public abstract class Repository<T> : IRepository where T : class
    //{
    //    protected abstract DbContext context { get; set; }

    //    readonly DbSet<T> dataSet;

    //    protected Repository(UnitOfWork uow)
    //    {
    //        uow.Register(this);
    //        dataSet = context.Set<T>();
    //    }

    //    public abstract T Add(T e);
    //    public abstract T Delete(T e);
    //    public abstract T Delete(int id);
    //    public abstract T Find(int id);
    //    public abstract void Update(T e);

    //    public int Count() => dataSet.Count();

    //    public void Save() => context.SaveChanges();
    //}
}