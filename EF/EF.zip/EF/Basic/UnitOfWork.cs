﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Basic
{

    public class UnitOfWork
    {
        readonly Dictionary<string, IRepository> container = new Dictionary<string, IRepository>();

        public void Register(IRepository repo)
        {
            if (container.ContainsKey(repo.GetType().Name)) { return; }
            container.Add(repo.GetType().Name, repo);
        }

        public void Commit() => container.ToList().ForEach(x => x.Value.Save());
    }
}
