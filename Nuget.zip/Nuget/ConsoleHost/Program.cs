﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Newtonsoft.Json;

namespace ConsoleApplication1
{
    class Account
    {
        public string Email { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public IList<string> Roles { get; set; }

        public Account() { Roles = new List<string>(); }
    }

    static class Program
    {
        static void Main()
        {
            Mapper.Initialize(cfg => cfg.CreateMap<Account, Account>());

            var account = new Account
            {
                Email = "meet.somebody@gmail.com",
                IsActive = true,
                CreatedDate = DateTime.Now,
                Roles = new List<string> { "User", "Admin" }
            };

            var anotherAccount = new Account()
            {
                Email = "meet.none@gmail.com"
            };

            Mapper.Map<Account, Account>(account, anotherAccount);

            Console.WriteLine(JsonConvert.SerializeObject(new List<Account> { account, anotherAccount }, Formatting.Indented));

            Console.WriteLine("LOOKUP");

            Console.WriteLine(JsonConvert.SerializeObject(new List<Account> { account, anotherAccount }.ToLookup(x => x.Email), Formatting.Indented));
        }
    }
}
